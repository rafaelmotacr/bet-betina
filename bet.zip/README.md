Casa de apostas fictícia baseada na betina da empiricus.
